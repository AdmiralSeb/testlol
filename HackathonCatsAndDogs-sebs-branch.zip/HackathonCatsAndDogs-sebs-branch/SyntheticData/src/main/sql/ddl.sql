CREATE TABLE Policies (
    id int identity primary key,
    petType char(50),
    breed char(50),
    sex char(1),
    age int,
    numberOfPets int,
    neutered bit,
    preExistingHeathCondition bit,
    postcode char(10)
)

CREATE TABLE #BulkPolicies (
    petType char(50),
    breed char(50),
    sex char(1),
    age int,
    numberOfPets int,
    neutered char(10),
    preExistingHeathCondition char(10),
    postcode char(10)
)

BULK INSERT #BulkPolicies
from 'hackathon_2023_pet_dataset.csv'
WITH (FORMAT = CSV, FIRSTROW = 2)

INSERT INTO Policies
(petType, breed, sex, age, numberOfPets, neutered, preExistingHeathCondition, postcode)
SELECT petType,
       breed,
       sex,
       age,
       numberOfPets,
       IIF(neutered = 'true', 1, 0),
       IIF(preExistingHeathCondition = 'true', 1, 0),
       postcode
FROM #BulkPolicies
