package com.admiral.hackathon.data.model

import jakarta.persistence.*
import java.util.*

@Entity
class Policy {
    @Id
    var id: UUID = UUID.randomUUID()

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "policyHolderId")
    lateinit var policyHolder: Person

    @OneToMany(cascade = [CascadeType.ALL], mappedBy = "currentPolicy")
    lateinit var pets: List<Pet>

    override fun toString(): String {
        return "Policy(id=$id, pets=$pets)"
    }
}