package com.admiral.hackathon.data.model

import jakarta.persistence.Entity
import jakarta.persistence.Id
import jakarta.validation.constraints.Size
import java.util.*

@Entity
class Address {
    @Id
    var id: UUID = UUID.randomUUID()

    @Size(min = 5, max = 10, message = "Postcodes are between 5 and 10 characters")
    //@Pattern(regexp = "/^[a-z]{1,2}\\d[a-z\\d]?\\s*\\d[a-z]{2}\$/i;")
    lateinit var postcode:String
    lateinit var firstLine:String

    override fun toString(): String {
        return "Address(id=$id, postcode='$postcode', firstLine='$firstLine')"
    }
}