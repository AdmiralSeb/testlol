package com.admiral.hackathon.data

import org.springframework.batch.core.Job
import org.springframework.batch.core.JobParametersBuilder
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing
import org.springframework.batch.core.launch.JobLauncher
import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@EnableBatchProcessing
@SpringBootApplication
class SyntheticDataApp

fun main(args: Array<String>) {
    println("Starting app ...")
    val ctx = runApplication<SyntheticDataApp>(*args)
    val job = ctx.getBean("generateData", Job::class.java)
    val jobLauncher = ctx.getBean(JobLauncher::class.java)
    val execution = jobLauncher.run(job, JobParametersBuilder().toJobParameters())
    println("Batch jop started at ${execution.startTime} - current status ${execution.status}")
}