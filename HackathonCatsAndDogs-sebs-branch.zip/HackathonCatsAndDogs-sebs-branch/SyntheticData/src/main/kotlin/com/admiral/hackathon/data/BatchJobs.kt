package com.admiral.hackathon.data

import com.admiral.hackathon.data.model.Person
import com.admiral.hackathon.data.repos.PersonRepo
import jakarta.persistence.EntityManagerFactory
import org.springframework.batch.core.*
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing
import org.springframework.batch.core.job.builder.JobBuilder
import org.springframework.batch.core.repository.JobRepository
import org.springframework.batch.core.step.builder.StepBuilder
import org.springframework.batch.item.ItemReader
import org.springframework.batch.item.ItemWriter
import org.springframework.context.ConfigurableApplicationContext
import org.springframework.context.annotation.Bean
import org.springframework.context.annotation.Configuration
import org.springframework.stereotype.Component
import org.springframework.transaction.PlatformTransactionManager

class GeneratingReader(val number:Int, val distributions: StatDistributions) :ItemReader<Person> {
    private var count = 0
    override fun read(): Person? {
        return if (count >= number) null
        else {
            count++
            println("Generating person $count ...")
            generateSyntheticPerson(distributions)
        }
    }

}

private const val STEP_DATA_GENERATOR = "Data Generate"

const val JOB_DATA_GENERATOR = "Generate data"

@EnableBatchProcessing
@Configuration
class BatchJobs {
    @Bean
    fun dataGeneration(repo:JobRepository, jpa: PersonRepo,
                       entityManagerFactory: EntityManagerFactory,
                       tm:PlatformTransactionManager,
                       distributions: StatDistributions):Step =
        StepBuilder(STEP_DATA_GENERATOR, repo)
            .chunk<Person, Person>(100, tm)
            .reader(syntheticData(distributions))
            .writer(dbSaverExplicit(entityManagerFactory))
            .build()

    private fun dbSaverExplicit(emf:EntityManagerFactory): ItemWriter<in Person> {
        return ItemWriter() { chunk ->
            println("Saving chunk")

            emf.createEntityManager().use { em ->
                val transaction = em.transaction
                transaction.begin()
                try {
//                    val addresses = chunk.items.map { p -> p.address }
//                    addresses.forEach(em::persist)
//                    val pets = chunk.items.fold(emptyList()) { list: List<Pet>, p: Person ->
//                        list + p.currentPolicies.flatMap(Policy::pets)
//                    }
//                    pets.forEach(em::persist)
//                    val policies = chunk.items.flatMap(Person::currentPolicies)
//                    policies.forEach(em::persist)
                    chunk.items.forEach(em::persist)

                    transaction.commit()
                } catch(e:RuntimeException) {
                    transaction.rollback()
                    throw e
                }
            }
        }
    }

    private fun dbSaverCascade(jpa: PersonRepo): ItemWriter<in Person> {
        return ItemWriter() { chunk ->
            println("Saving chunk")
            jpa.saveAllAndFlush(chunk.items)
        }
    }

    private fun syntheticData(distributions: StatDistributions): ItemReader<out Person> {
        return GeneratingReader(10000, distributions)
    }

    @Bean
    fun distributions(): StatDistributions {
        return loadStats()
    }

    @Bean
    fun generateData(repo:JobRepository, listener:JobExecutionListener, stepListener: StepExecutionListener, dataGeneration:Step):Job
        = JobBuilder(JOB_DATA_GENERATOR, repo)
        .start(dataGeneration)
        .listener(listener).listener(stepListener)
        .build()
}

@Component
class JobListener(val ctx:ConfigurableApplicationContext) : JobExecutionListener {
    override fun beforeJob(jobExecution: JobExecution) {
        println("Starting job ...")
        super.beforeJob(jobExecution)
    }
    override fun afterJob(jobExecution: JobExecution) {
        println("Finished job")
        super.afterJob(jobExecution)

        // exitProcess(SpringApplication.exit(ctx))
    }
}

@Component
class StepReporter :StepExecutionListener {
    override fun beforeStep(stepExecution: StepExecution) {
        println("Starting step ${stepExecution.readCount}...")
        super.beforeStep(stepExecution)
    }

    override fun afterStep(stepExecution: StepExecution): ExitStatus? {
        println("Done step ${stepExecution.writeCount}")
        return super.afterStep(stepExecution)
    }
}