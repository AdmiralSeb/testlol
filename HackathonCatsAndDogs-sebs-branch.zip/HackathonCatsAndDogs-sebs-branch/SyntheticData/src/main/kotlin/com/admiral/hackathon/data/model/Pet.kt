package com.admiral.hackathon.data.model

import jakarta.persistence.Entity
import jakarta.persistence.FetchType
import jakarta.persistence.Id
import jakarta.persistence.JoinColumn
import jakarta.persistence.ManyToOne
import java.util.*

@Entity
class Pet {
    @Id
    var id: UUID = UUID.randomUUID()

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "ownerId")
    lateinit var owner: Person
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "currentPolicyId")
    lateinit var currentPolicy: Policy

    lateinit var name: String
    lateinit var type: String
    lateinit var breed: String
    var age: Int = 0
    var neutered: Boolean = false
    var preExistingConditions: Boolean = false

    override fun toString(): String {
        return "Pet(id=$id, owner=${owner.id}, policy=${currentPolicy.id}, name='$name', type='$type', breed='$breed', age=$age, neutered=$neutered, preExistingConditions=$preExistingConditions)"
    }
}