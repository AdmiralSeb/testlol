package com.admiral.hackathon.data.model

import jakarta.persistence.*
import java.util.*

@Entity
class Person {
    @Id
    var id: UUID = UUID.randomUUID()
    lateinit var firstName: String
    lateinit var surname: String

    @OneToOne(cascade = [CascadeType.ALL], fetch = FetchType.LAZY)
    @JoinColumn(name = "addressId")
    lateinit var address: Address

    @OneToMany(cascade = [CascadeType.ALL], mappedBy = "policyHolder")
    lateinit var currentPolicies: List<Policy>

    override fun toString(): String {
        return "Person(id=$id, firstName='$firstName', surname='$surname', address=${address.id}, currentPolicies=$currentPolicies)"
    }
}