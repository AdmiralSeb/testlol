package com.admiral.hackathon.data

import com.admiral.hackathon.data.model.Address
import com.admiral.hackathon.data.model.Person
import com.admiral.hackathon.data.model.Pet
import com.admiral.hackathon.data.model.Policy
import com.opencsv.CSVParserBuilder
import com.opencsv.CSVReaderBuilder
import java.io.FileNotFoundException
import java.io.InputStreamReader
import java.lang.IllegalStateException
import kotlin.random.Random

fun loadStats(): StatDistributions {
    val petcount = loadCsv<Int>("petcount.csv", String::toInt)
    val names = loadCsv<String>("names.csv", ::properNounCase)
    val surnames = loadCsv<String>("surnames.csv", ::properNounCase)
    val postcodeAreas = loadFlatFile("postcode-areas.txt") { it }
    val petnames = loadFlatFile("pet-names.txt") { it }
    val defaultConditions = loadCsv("conditions.csv", String::toBoolean)
    val petTypes = loadCsv<PetType>("pet-types.csv") { name ->
        val breedFileName = name.lowercase().replace(" ", "-") + "-breeds.txt"
        val ageFileName = breedFileName.replace("breeds.txt", "ages.csv")
        val neuteredFile = breedFileName.replace("breeds.txt", "neutered.csv")
        val conditionsFile = breedFileName.replace("breeds.txt", "conditions.csv")
        val breeds = loadFlatFile(breedFileName) { it }
        val age = loadCsv(ageFileName, String::toInt)
        val neutered = loadCsv(neuteredFile, String::toBoolean)
        val conditions = try {
            loadCsv(conditionsFile, String::toBoolean)
        } catch (e: FileNotFoundException) {
            defaultConditions
        }
        PetType(name, breeds, age, neutered, conditions)
    }
    return StatDistributions(petcount, names, surnames, postcodeAreas, petnames, petTypes)
}

private fun properNounCase(surname: String) = surname.substring(0, 1).uppercase() + surname.substring(1).lowercase()

private const val DISTRIBUTION_HEADER = "distribution"

private fun <T> loadFlatFile(file:String, converter: (String) -> T):StatDistribution<T> {
    val stream = loadResourceFile(file)
    val lines = InputStreamReader(stream).useLines { it.map(String::trim).map(converter).toList() }
    return FlatStatDistrubion<T>(lines)
}

private fun loadResourceFile(file: String) = (Thread.currentThread().contextClassLoader.getResourceAsStream(file)
    ?: throw FileNotFoundException("Failed to load file $file"))

private fun <T> loadCsv(file:String, converter:(String) -> T):StatDistribution<T> {
    val parser = CSVParserBuilder().build()

    val stream = loadResourceFile(file)
    val records = stream.let { InputStreamReader(it) }
        .use { reader ->
            val csv = CSVReaderBuilder(reader).withCSVParser(parser).build()
            val header = csv.readNext()
            if (header[1].trim() != DISTRIBUTION_HEADER)
                throw IllegalArgumentException("CSV should have 2 columns second is called '$DISTRIBUTION_HEADER' ${header.asList()}")
            //val lbl = header[0]

            csv.readAll()
        }
    val values = records.map {
        val record = it.map(String::trim)
        val v = converter(record[0])
        val count = record[1].toInt()
        DistributionValue<T>(count, v)
    }

    return FrequencyStatDistribution(values)
}

data class PetType (
    val name:String,
    val breeds:StatDistribution<String>,
    val age:StatDistribution<Int>,
    val neutered:StatDistribution<Boolean>,
    val conditions:StatDistribution<Boolean>
)
data class StatDistributions(
    val petcount:StatDistribution<Int>,
    val names:StatDistribution<String>,
    val surnames:StatDistribution<String>,
    val postcodeAreas:StatDistribution<String>,
    val petNames:StatDistribution<String>,
    val petTypes:StatDistribution<PetType>
)

fun main() {
    val d = loadStats()
    (0..10000).forEach {
        println(" ${generateSyntheticPerson(d)}")
    }
}

fun generateSyntheticPerson(distributions: StatDistributions): Person {
    val p = Person()
    val policy = Policy()
    val numberOfPets = distributions.petcount.pick()
    val pets = (1..numberOfPets).map {
        generatePet(p, policy, distributions)
    }
    p.firstName = distributions.names.pick()
    p.surname = distributions.surnames.pick()
    p.address = generateAddress(distributions)

    policy.pets = pets
    policy.policyHolder = p
    p.currentPolicies = listOf(policy)
    return p
}

private fun generateAddress(distributions: StatDistributions): Address {
    val addr = Address()
    val postcodeArea = distributions.postcodeAreas.pick()
    addr.postcode = postcodeArea + " " + Random.nextInt(0, 9) + "ZZ"
    addr.firstLine = "${Random.nextInt(1, 231)} Admiral Street"
    return addr
}

private fun generatePet(owner:Person, policy: Policy, distributions: StatDistributions): Pet {
    val pet = Pet()
    pet.owner = owner
    pet.currentPolicy = policy
    pet.name = distributions.petNames.pick()
    val type = distributions.petTypes.pick()
    pet.type = type.name
    pet.breed = type.breeds.pick()
    pet.age = type.age.pick()
    pet.neutered = type.neutered.pick()
    pet.preExistingConditions = type.conditions.pick()
    return pet
}

data class DistributionValue<T>(
    val count:Int,
    val value:T
)

interface StatDistribution<T> {
    fun pick():T
}

data class FlatStatDistrubion<T>(val items:List<T>) : StatDistribution<T> {
    override fun pick(): T {
        val rand = Random.nextInt(0, items.size)
        return items[rand]
    }
}

data class FrequencyStatDistribution<T>(val items:List<DistributionValue<T>>) : StatDistribution<T> {
    val total:Int = items.fold(0, { acc, dv -> acc + dv.count })

    override fun pick():T {
        val rand = Random.nextInt(1, total + 1)
        var current = 0
        for (item in items) {
            current += item.count
            if (current >= rand) return item.value
        }
        throw IllegalStateException("rand outside the range? $rand $current $total")
    }
}
