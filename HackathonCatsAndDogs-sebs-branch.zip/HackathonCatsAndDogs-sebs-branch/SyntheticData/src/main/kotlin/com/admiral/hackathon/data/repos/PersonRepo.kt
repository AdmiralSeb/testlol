package com.admiral.hackathon.data.repos

import com.admiral.hackathon.data.model.Person
import org.springframework.data.jpa.repository.JpaRepository

interface PersonRepo : JpaRepository<Person, Int> {

}