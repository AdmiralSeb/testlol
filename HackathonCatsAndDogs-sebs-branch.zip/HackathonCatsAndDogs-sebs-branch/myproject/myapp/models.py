from django.db import models

class PetInfo(models.Model):
    PET_TYPE_CHOICES = [
        ('DOG', 'Dog'),
        ('CAT', 'Cat'),
        # Add more if needed
    ]
    PetID = models.AutoField(primary_key=True)
    PetType = models.CharField(max_length=50, choices=PET_TYPE_CHOICES)
    PetBreed = models.CharField(max_length=100)
    Policy = models.TextField()
    PolicyStartDate = models.DateField()
    PolicyEndDate = models.DateField()

class PetHealth(models.Model):
    PetID = models.ForeignKey(PetInfo, on_delete=models.CASCADE, related_name='health_records')
    TimeStamp = models.DateTimeField(auto_now_add=True)
    PetBPM = models.IntegerField()
    Latitude = models.FloatField()
    Longitude = models.FloatField()
    Steps = models.IntegerField()

class Product(models.Model):
    PRODUCT_TYPE_CHOICES = [
        ('FOOD', 'Pet Food'),
        ('ACCESSORY', 'Accessory'),
        ('TOY', 'Toy'),
        # Add more if needed
    ]
    ProductID = models.AutoField(primary_key=True)
    Name = models.CharField(max_length=200)
    Description = models.TextField()
    Price = models.DecimalField(max_digits=10, decimal_places=2)
    ProductType = models.CharField(max_length=50, choices=PRODUCT_TYPE_CHOICES)
    Stock = models.IntegerField()
