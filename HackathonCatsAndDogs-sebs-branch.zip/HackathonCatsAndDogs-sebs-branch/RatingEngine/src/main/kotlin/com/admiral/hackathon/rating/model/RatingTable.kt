package com.admiral.hackathon.rating.model

import mu.KotlinLogging
import kotlin.IllegalStateException

val log = KotlinLogging.logger {  }

class RatingRow(
    val labels: List<String>,
    val factors: List<Float>,
    val rate:Float
)
class RatingTable(
    val name:String,
    val factors: List<String>,
    val labels: List<String>,
    val cols: List<String>,
    val rows: List<RatingRow>
) {
    fun rate(req: RatingRequest):Float {
        if (!req.factors.keys.containsAll(factors)
            || !req.labels.keys.containsAll(labels)) {
            log.info { "Missing rating factors for $name to rate" }
            return 1.0f
        }
        log.info { "Rating on $name for request..." }
        val reqLabels = labels.map { req.labels.get(it) }
        return try {
            val reqFactors = factors.map { factorName ->
                req.factors[factorName] ?: throw IllegalStateException("Null factor should be discounted above")
            }
            val filteredTable = rows.filter { row -> row.labels.equals(reqLabels) }
            val result = filteredTable.firstOrNull { row ->
                row.factors.zip(reqFactors).all { (rowVal, reqFactor) ->
                    rowVal > reqFactor
                }
            }
            log.info {
                if (result == null) "No match on table - using default of 1.0"
                else "Matched table rating ${result.rate}"
            }
            result?.rate ?: 1.0f
        } catch (e:IllegalStateException) {
            log.error("Logic error in rating table")
            1.0f
        }
    }
}