package com.admiral.hackathon.rating

import mu.KotlinLogging
import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication
import org.springframework.context.event.ContextStartedEvent
import org.springframework.context.event.EventListener

private val logger = KotlinLogging.logger {  }

@SpringBootApplication
class RatingEngineApplication {
	@EventListener
	fun started(evt:ContextStartedEvent) {
		logger.info {
			"Application started - try swagger UI http://localhost:8080/swagger-ui/index.html"
		}
	}

}

fun main(args: Array<String>) {
	val ctx = runApplication<RatingEngineApplication>(*args)
	ctx.start()
}
