package com.admiral.hackathon.rating.api

import com.admiral.hackathon.rating.model.RatingRequest
import com.admiral.hackathon.rating.model.RatingResult
import com.admiral.hackathon.rating.model.RatingTable
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RestController

@RestController
class RatingAPI(@Autowired val tables:List<RatingTable>) {
    @GetMapping("/")
    fun getStatus():String {
        return "hello"
    }
    @PostMapping("/rating")
    fun doRating(@RequestBody request: RatingRequest): RatingResult {
        val baseRate = 100.0f
        val rate = tables.fold(baseRate) {acc, table -> acc * table.rate(request) }
        return RatingResult(result = rate)
    }
}