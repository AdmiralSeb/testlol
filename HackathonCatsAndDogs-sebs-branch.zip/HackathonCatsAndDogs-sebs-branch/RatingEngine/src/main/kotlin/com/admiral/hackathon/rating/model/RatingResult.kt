package com.admiral.hackathon.rating.model

class RatingResult(val result:Float)