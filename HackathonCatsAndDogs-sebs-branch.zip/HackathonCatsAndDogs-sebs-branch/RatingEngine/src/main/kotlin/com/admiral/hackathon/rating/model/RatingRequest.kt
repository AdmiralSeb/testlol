package com.admiral.hackathon.rating.model

import io.swagger.v3.oas.annotations.media.Schema

class RatingRequest(
    @Schema(description = "Set of labels for the rating request", example = "{ \"breed\": \"Labrador\"}")
    val labels:Map<String, String>,
    @Schema(description = "Set of values used as rating factors", example = "{ \"age\": 5.5 }")
    val factors:Map<String, Float>)