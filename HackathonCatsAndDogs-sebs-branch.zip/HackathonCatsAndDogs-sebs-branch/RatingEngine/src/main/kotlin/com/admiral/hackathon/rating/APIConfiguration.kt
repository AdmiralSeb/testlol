package com.admiral.hackathon.rating

import com.admiral.hackathon.rating.model.RatingRow
import com.admiral.hackathon.rating.model.RatingTable
import com.opencsv.CSVReader
import mu.KotlinLogging
import org.springframework.context.annotation.Bean
import org.springframework.context.annotation.Configuration
import org.springframework.core.io.ClassPathResource

val log = KotlinLogging.logger {  }
class InvalidFormatException(message:String): Exception(message) {
}

@Configuration
class APIConfiguration {
    @Bean
    fun ratingTables(): List<RatingTable> {
        val tablesResource = ClassPathResource("rates/tables")
        val tables = tablesResource.getContentAsString(Charsets.US_ASCII).split('\r', '\n')
        val ratingTables = tables.filter { it.isNotBlank() }
            .map { (it to ClassPathResource("rates/$it")) }
            .map { (name, resource) ->
                try {
                    log.info { "loading $name from ${resource.path}" }
                    loadTable(name, resource)
                } catch (e:InvalidFormatException) {
                    log.error(e) { "Failed to parse $name"}
                    null
                } }
            .filterNotNull()
        ratingTables.forEach { log.info { "Loaded ${it.name} with ${it.rows.size} factors ${it.factors} lbls ${it.labels}"} }
        return ratingTables
    }

    private fun loadTable(name:String, resource: ClassPathResource): RatingTable =
        resource.inputStream.reader(Charsets.UTF_8).use {reader ->
            CSVReader(reader).use {csvReader ->
                val header = csvReader.readNext()
                val factors = (0 until header.size)
                    .map{ it to header[it]}
                    .filter { (_, lbl) -> lbl.trim().startsWith("f_") }
                    .map { (idx, lbl) -> idx to lbl.trim().substring(2) }
                val labels = (0 until header.size)
                    .map{ it to header[it]}
                    .filter { (idx, lbl) -> lbl.trim().startsWith("l_") }
                    .map { (idx, lbl) -> idx to lbl.trim().substring(2) }
                val rateIdx = header.indexOfFirst { it.trim().equals("rate")}
                if (rateIdx == -1) throw InvalidFormatException("Missing rate column")
                if (factors.isEmpty() && labels.isEmpty()) throw InvalidFormatException("No rating factors")
                val lines = csvReader.readAll()
                val factorIdxs = factors.map { (idx, _) -> idx }
                val lblIdxs = labels.map { (idx, _) -> idx}
                val rows = lines.map {line ->
                    RatingRow(
                        factors = factorIdxs.map { line[it].toFloat() },
                        labels = lblIdxs.map { line[it] },
                        rate = line[rateIdx].toFloat()
                    )
                }

                RatingTable(
                    name = name,
                    factors = factors.map { (_, fct) -> fct },
                    labels = labels.map { (_, lbl) -> lbl },
                    cols = header.toList(),
                    rows = rows
                )
            }
        }
}