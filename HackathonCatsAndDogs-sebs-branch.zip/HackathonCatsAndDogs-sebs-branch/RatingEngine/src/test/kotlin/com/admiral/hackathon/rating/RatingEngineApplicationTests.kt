package com.admiral.hackathon.rating

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class RatingEngineApplicationTests {

	@Test
	fun contextLoads() {
	}

}
